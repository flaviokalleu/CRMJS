import React from "react";

const CardGrid = () => {
  const properties = [
    {
      id: 1,
      title: "Casa Moderna",
      image: "https://via.placeholder.com/500",
      description: "Uma casa moderna com design contemporâneo e conforto.",
    },
    {
      id: 2,
      title: "Apartamento Luxuoso",
      image: "https://via.placeholder.com/500",
      description: "Apartamento de luxo em uma localização privilegiada.",
    },
    {
      id: 3,
      title: "Chácara Aconchegante",
      image: "https://via.placeholder.com/500",
      description: "Chácara ideal para quem busca tranquilidade.",
    },
    {
      id: 4,
      title: "Casa de Campo",
      image: "https://via.placeholder.com/500",
      description: "Casa de campo com vista para a natureza.",
    },
    {
      id: 5,
      title: "Cobertura na Praia",
      image: "https://via.placeholder.com/500",
      description: "Cobertura com vista para o mar.",
    },
    {
      id: 6,
      title: "Apartamento em São Paulo",
      image: "https://via.placeholder.com/500",
      description: "Apartamento moderno em São Paulo.",
    },
  ];

  // Limitar a exibição a 4 propriedades
  const displayedProperties = properties.slice(0, 4);

  return (
    <div className="">
      <h2 className="text-3xl text-black font-bold text-center mb-6 text-white">
        Propriedades em Destaque
      </h2>
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {displayedProperties.map((property) => (
          <div
            key={property.id}
            className="max-w-sm border rounded-lg shadow-lg transition-transform duration-300 hover:scale-105 mb-5" // Adicionado mb-5 para o espaçamento inferior
          >
            <a href="#">
              <img
                className="rounded-t-lg h-48 w-full object-cover"
                src={property.image}
                alt={property.title}
              />
            </a>
            <div className="p-4">
              <a href="#">
                <h5 className="mb-2 text-xl text-black font-bold tracking-tight">
                  {property.title}
                </h5>
              </a>
              <p className="mb-3 font-normal text-gray-400 overflow-hidden text-ellipsis whitespace-nowrap">
                {property.description}
              </p>
              <a
                href="#"
                className="inline-flex items-center px-2 py-1 text-sm font-medium text-center text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition duration-300"
              >
                Ler mais
                <svg
                  className="rtl:rotate-180 w-3.5 h-3.5 ms-2"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 14 10"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M1 5h12m0 0L9 1m4 4L9 9"
                  />
                </svg>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CardGrid;
